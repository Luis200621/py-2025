#Nombres de los integrantes: Luis Muñoz y Dayana Levicoy 

suma = 0
a = 500
b = 456

while a <= 800:
    suma += a 
    suma += b
    a += 10
    b -= 2 

print('Los resultados de las secuencias N°1 y N°2 son: ',suma)
